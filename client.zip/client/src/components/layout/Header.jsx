const Header = () => {
    return <h1 className="title">Actor Application</h1>
}

export default Header